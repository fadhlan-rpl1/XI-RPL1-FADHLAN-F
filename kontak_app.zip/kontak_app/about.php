<!DOCTYPE html>
<html>
<head>
    <title>About Us</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>👥 Tentang Kami</h2>
        <p>Aplikasi ini dibuat untuk tugas akhir kelas XI sebagai sistem pengelolaan data kontak berbasis web.</p>
        <ul>
            <li>🧑 Analis: Budi Prabu Erucakra</li>
            <li>🎨 UI: Fadhlan Fadhlilah & Fariz Islamy Hakim</li>
            <li>💻 Programmer: Abdul Karim Kamaluddin</li>
        </ul>
        <a href="index.php" class="button btn-gray">🔙 Kembali ke Halaman Utama</a>
    </div>
</body>
</html>
