<?php include 'db.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Data Kontak</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>📋 Daftar Kontak</h2>
    <div class="button-container">
        <a href="create.php" class="button btn-green">➕ Tambah Kontak</a>
        <a href="about.php" class="button btn-purple">👥 Tentang Kami</a>
    </div>
    <table>
        <tr>
            <th>Nama</th>
            <th>Email</th>
            <th>Nomor HP</th>
            <th>Aksi</th>
        </tr>
        <?php
        $query = mysqli_query($conn, "SELECT * FROM kontak") or die("Query error: " . mysqli_error($conn));
        while ($row = mysqli_fetch_assoc($query)) {
            echo "<tr>
                    <td>{$row['nama']}</td>
                    <td>{$row['email']}</td>
                    <td>{$row['no_hp']}</td>
                    <td>
                        <a href='edit.php?id={$row['id']}' class='button btn-orange'>✏️ Edit</a>
                        <a href='delete.php?id={$row['id']}' class='button btn-red' onclick='return confirm(\"Yakin hapus kontak ini?\")'>🗑️ Hapus</a>
                    </td>
                  </tr>";
        }
        ?>
    </table>
</body>
</html>
